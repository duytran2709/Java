// Exercise 14.12 Template: Convert.java
// Temperature-conversion program
import javax.swing.JFrame;

public class Convert
{
   public static void main( String[] args )
   {
      //Create new ConvertFrame
      //Set default close option
      // set frame size
      // display frame
   } // end main
} // end class Convert


