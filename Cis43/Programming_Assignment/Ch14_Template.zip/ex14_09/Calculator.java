// Exercise 14.9 Template: Calculator.java
// Program creates a GUI that resembles a calculator.
import javax.swing.JFrame;

public class Calculator
{
   public static void main( String[] args )
   {
      // create new CalculatorFrame
	  // set default close operation
	  // set frame size
	  // display frame
	
   } 
}  // end class Calculator


