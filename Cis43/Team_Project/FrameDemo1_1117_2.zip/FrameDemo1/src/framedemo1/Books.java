/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package framedemo1;
import java.util.ArrayList;

class Books {
        public static void main(String args[]){
        ArrayList<String[]> Books = new ArrayList<String[]>();
        Books.add(new String[]{"Book1", "1"});
        Books.add(new String[]{"Book2", "1"});
        Books.add(new String[]{"Book3", "1"});
        System.out.print(Books);
    }
}
