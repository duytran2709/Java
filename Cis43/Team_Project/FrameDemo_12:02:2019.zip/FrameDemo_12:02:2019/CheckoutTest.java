
/**
 * CheckoutTest
 */
import java.io.*;
import java.util.ArrayList;
import javax.swing.JFrame;
public class CheckoutTest {

    
    public static void main(String[] args) {
        
        // ArrayList<String> borrowed_books = new ArrayList<String>();

        // Checkout checkout = new Checkout(borrowed_books);
        // checkout.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // checkout.setLocationRelativeTo(null);
        // checkout.setSize(600,500);
        // checkout.setResizable(false);
        // checkout.setVisible(true);
        int i = 0; 
        if(i == 0)
        {
        i = 1;
        First_Screen first_screen = new First_Screen();
        first_screen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        first_screen.setLocationRelativeTo(null);
        first_screen.setSize(600,500);
        first_screen.setResizable(false);
        first_screen.setVisible(true);
        }
        
        
        
    }
}