class Lab2 {
	public static void main(String[] arg) {
	
	}
	// Problem 1
	public static int min(int [] a, int begin, int end) {

	}
	
	// Problem 2
	public static long computePay(int day) {
	
	}
	
	public static long computeSavings(int day) {
	
	}
	
	// Problem 3
	public static int countSubstring(String s1, String s2) {
	
	
	}
}