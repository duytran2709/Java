import java.util.* ;
public class Lab6
{
	// Problem 1
	public static <T extends Comparable<? super T>> 
	       boolean inArrayIterativeSorted(T[] anArray, T anEntry) {
		
	}
	
	// Problem 2
	public static <T extends Comparable<? super T>>
		Interval findInterval(T[] sortedData, List<T> targetValues){
		
	}
	// Problem 3
	pubic static <T extends Comparable<? super T>> boolean  isSorted(T[ ] a) {
		
		return false;
	}
	
	// Problem 4
    public static <T extends Comparable<? super T>> void modifiedSelectionSort(T[] a, int n) {
	
    } 
      
} 
